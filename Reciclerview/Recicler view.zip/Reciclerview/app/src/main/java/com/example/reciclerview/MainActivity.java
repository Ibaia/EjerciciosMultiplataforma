package com.example.reciclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity<Anime> extends AppCompatActivity {

    public ArrayList<MainActivity.Anime> listaAnime= new ArrayList<>();

    RecyclerView myRecycler = findViewById(R.id.reciclerView);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        AnimeAdapter animeAdapter = new AnimeAdapter();
        myRecycler.setItemAnimator(new DefaultItemAnimator());
        myRecycler.addItemDecoration(new DividerItemDecoration(getBaseContext(), LinearLayoutManager.VERTICAL));
        myRecycler.setAdapter(bookAdapter);

    }

    //Clase anime
    public class Anime{
        protected String name;
        protected String description;
    }

    //Añadir datos al ArrayList
    public void loadArrayList(){
        listaAnime.add(new Anime( ));
    }

    //Cambia el arraylist a RecyclerView
    //MyReciclerAdapter myReciclerAdapter= new MyRecyclerAdapter(listaAlumnos);
    //myRecycler.setAdapter(myRecyclerAdapter);
}