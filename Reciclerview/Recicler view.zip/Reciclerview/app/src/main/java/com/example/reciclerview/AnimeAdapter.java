package com.example.reciclerview;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AnimeAdapter extends RecyclerView.Adapter<AnimeAdapter.AnimeBasicViewHolder{


    public static class AnimeBasicViewHolder{
        public TextView txName;
        public TextView txDescription;
        public TextView txRate;

        public AnimeBasicViewHolder (View itemView){

            super(itemView);

            txName=itemView.findViewById(R.id.txName);
            txDescription=itemView.findViewById(R.id.txDescription);

        }
    }

    @NonNull
    @Override
    public AnimeAdapter.AnimeBasicViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


    }

    @Override
    public void onBindViewHolder(@NonNull AnimeAdapter.AnimeBasicViewHolder holder, int position) {


    }

    @Override
    public int getItemCount() {
        return 0;
    }
}
