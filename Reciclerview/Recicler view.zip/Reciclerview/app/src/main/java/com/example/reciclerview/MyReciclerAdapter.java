package com.example.reciclerview;

public class MyReciclerAdapter {

}
